package com.example.gatherforgood;
public class ApiKeys {
    public static final String MAPS_API_KEY = "AIzaSyAitlEJBhC7-lDCmgaUuySCWtbYJ2Qo8HM";
}
