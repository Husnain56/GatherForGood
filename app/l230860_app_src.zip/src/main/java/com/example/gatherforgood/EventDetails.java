package com.example.gatherforgood;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.button.MaterialButton;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FieldValue;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QueryDocumentSnapshot;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class EventDetails extends AppCompatActivity {

    TextView tvEventTitle, tvOrganizerName, tvOrganizerNameDetail,
            tvEventDate, tvEventTime, tvEventLocation,
            tvSlots, tvParticipantCount, tvDescription,
            tvReadMore, tvEventType, tvStatus, tvRequirementGender, tvRequirements;

    MaterialButton btnCancelEvent;

    TextView tvEventEndDate, tvEventEndTime;

    Button         btnJoin;
    LinearLayout llLocation;
    MaterialButton btnOpenMaps, btnGroupChat, btnMessageHost;
    ImageButton    btnBack;
    ProgressBar    progressBar;
    LinearLayout   layoutChatButtons;

    LinearLayout            layoutParticipants;
    ProgressBar             progressParticipants;
    TextView                tvNoParticipants;
    RecyclerView rvParticipants;
    ParticipantAdapter      participantAdapter;
    ArrayList<ParticipantItem> participantList = new ArrayList<>();

    Event            event;
    FirebaseFirestore db;
    String           currentUid;
    boolean          isAlreadyJoined = false;
    boolean          isHost          = false;
    boolean          descExpanded    = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_event_details);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        db         = FirebaseFirestore.getInstance();
        currentUid = FirebaseAuth.getInstance().getCurrentUser().getUid();

        init();
        bindData();
        setBaseListeners();
    }

    private void init() {
        tvEventTitle          = findViewById(R.id.tvEventTitle);
        tvOrganizerName       = findViewById(R.id.tvOrganizerName);
        tvOrganizerNameDetail = findViewById(R.id.tvOrganizerNameDetail);
        tvEventDate           = findViewById(R.id.tvEventDate);
        tvEventTime           = findViewById(R.id.tvEventTime);
        tvEventLocation       = findViewById(R.id.tvEventLocation);
        tvSlots               = findViewById(R.id.tvSlots);
        tvParticipantCount    = findViewById(R.id.tvParticipantCount);
        tvDescription         = findViewById(R.id.tvDescription);
        tvReadMore            = findViewById(R.id.tvReadMore);
        tvEventType           = findViewById(R.id.tvEventType);
        tvStatus              = findViewById(R.id.tvStatus);

        btnJoin           = findViewById(R.id.btnJoin);
        btnOpenMaps       = findViewById(R.id.btnOpenMaps);
        btnBack           = findViewById(R.id.btnBack);
        progressBar       = findViewById(R.id.progressBar);
        layoutChatButtons = findViewById(R.id.layoutChatButtons);
        btnGroupChat      = findViewById(R.id.btnGroupChat);
        btnMessageHost    = findViewById(R.id.btnMessageHost);

        layoutParticipants   = findViewById(R.id.layoutParticipants);
        progressParticipants = findViewById(R.id.progressParticipants);
        tvNoParticipants     = findViewById(R.id.tvNoParticipants);
        rvParticipants       = findViewById(R.id.rvParticipants);

        rvParticipants.setLayoutManager(new LinearLayoutManager(this));
        rvParticipants.setHasFixedSize(true);

        participantAdapter = new ParticipantAdapter(this, participantList, null);
        rvParticipants.setAdapter(participantAdapter);

        btnCancelEvent = findViewById(R.id.btnCancelEvent);

        tvRequirementGender = findViewById(R.id.tvRequirementGender);
        tvRequirements      = findViewById(R.id.tvRequirements);

        tvEventEndDate = findViewById(R.id.tvEventEndDate);
        tvEventEndTime = findViewById(R.id.tvEventEndTime);

        llLocation = findViewById(R.id.llLocation);

        event = (Event) getIntent().getSerializableExtra("event");
    }

    private void bindData() {
        tvEventTitle.setText(event.getTitle());
        tvOrganizerName.setText(event.getHostName());
        tvOrganizerNameDetail.setText(event.getHostName());
        tvEventDate.setText(event.getDate());
        tvEventTime.setText(event.getTime());
        if (event.getEndDate() != null && !event.getEndDate().isEmpty()) {
            tvEventEndDate.setText(event.getEndDate());
            tvEventEndTime.setText(event.getEndTime());
        } else {
            tvEventEndDate.setText("—");
            tvEventEndTime.setText("—");
        }
        tvEventLocation.setText(event.getLocation());
        tvDescription.setText(event.getDescription());
        tvEventType.setText(event.getEventType().toUpperCase());
        tvStatus.setText(event.getStatus().toUpperCase());
        tvSlots.setText(event.getVolunteersJoined() + "/" + event.getVolunteersRequired());
        tvParticipantCount.setText(event.getVolunteersJoined() + " Attending");
        tvRequirementGender.setText(event.getGenderSetting());

        if(event.getRequirements() == null){
            tvRequirements.setText("No Requirements");
        }
        else {
            tvRequirements.setText(event.getRequirements());
        }

        isHost = event.getHostUid().equals(currentUid);

        if ("cancelled".equals(event.getStatus())) {
            btnJoin.setText("Event Cancelled");
            btnJoin.setEnabled(false);
            btnJoin.setAlpha(0.5f);
            tvStatus.setTextColor(getColor(android.R.color.holo_red_light));
            layoutChatButtons.setVisibility(View.GONE);
            if (isHost) btnCancelEvent.setVisibility(View.GONE);
            return;
        }

        if (isHost) {
            layoutChatButtons.setVisibility(View.VISIBLE);
            setupHostControls();
        } else {
            checkIfJoined();
        }
        if (!isHost && ("finished".equals(event.getStatus()) || event.getVolunteersJoined() >= event.getVolunteersRequired())) {
            btnJoin.setEnabled(false);
            btnJoin.setText("finished".equals(event.getStatus()) ? "Event Ended" : "Slots Full");
            btnJoin.setAlpha(0.5f);
        }
    }

    private void setBaseListeners() {
        btnBack.setOnClickListener(v -> finish());
        btnOpenMaps.setOnClickListener(v -> openGoogleMaps());
        llLocation.setOnClickListener(v->openGoogleMaps());

        tvReadMore.setOnClickListener(v -> {
            if (descExpanded) {
                tvDescription.setMaxLines(4);
                tvReadMore.setText("Read more");
            } else {
                tvDescription.setMaxLines(Integer.MAX_VALUE);
                tvReadMore.setText("Read less");
            }
            descExpanded = !descExpanded;
        });

        btnGroupChat.setOnClickListener(v -> {
            Intent intent = new Intent(this, ChatActivity.class);
            intent.putExtra("chatType",       "group");
            intent.putExtra("chatId",         event.getEventId());
            intent.putExtra("chatName",       event.getTitle());
            intent.putExtra("chatCollection", "volunteerEvents");
            startActivity(intent);
        });

    }

    private void setupHostControls() {
        btnJoin.setVisibility(View.VISIBLE);
        btnJoin.setEnabled(true);

        btnCancelEvent.setVisibility(View.VISIBLE);
        btnCancelEvent.setOnClickListener(v -> showCancelDialog());

        btnMessageHost.setText("View Messages");
        btnMessageHost.setIcon(getResources().getDrawable(R.drawable.ic_chat, getTheme()));
        btnMessageHost.setOnClickListener(v -> {
            Intent intent = new Intent(this, InboxActivity.class);
            intent.putExtra("eventId",    event.getEventId());
            intent.putExtra("eventTitle", event.getTitle());
            android.util.Log.d("INBOX", "passing eventId: " + event.getEventId());
            android.util.Log.d("INBOX", "passing eventTitle: " + event.getTitle());
            startActivity(intent);
        });

        updateHostButton();
        loadParticipants();
    }

    private void loadParticipants() {
        layoutParticipants.setVisibility(View.VISIBLE);
        progressParticipants.setVisibility(View.VISIBLE);
        rvParticipants.setVisibility(View.GONE);
        tvNoParticipants.setVisibility(View.GONE);

        db.collection("volunteerEvents")
                .document(event.getEventId())
                .collection("participants")
                .orderBy("joinedAt", Query.Direction.ASCENDING)
                .get()
                .addOnSuccessListener(snapshots -> {
                    int nonHostCount = 0;
                    for (QueryDocumentSnapshot doc : snapshots) {
                        if (!"host".equals(doc.getString("role"))) nonHostCount++;
                    }

                    if (nonHostCount == 0) {
                        progressParticipants.setVisibility(View.GONE);
                        tvNoParticipants.setVisibility(View.VISIBLE);
                        return;
                    }

                    int[] pending = {nonHostCount};
                    participantList.clear();

                    for (QueryDocumentSnapshot doc : snapshots) {
                        String role = doc.getString("role");
                        if ("host".equals(role)) continue;

                        String uid      = doc.getString("uid");
                        String name     = doc.getString("name");
                        long   joinedAt = doc.getLong("joinedAt") != null ? doc.getLong("joinedAt") : 0L;

                        db.collection("users")
                                .document(uid)
                                .get()
                                .addOnSuccessListener(userDoc -> {
                                    String gender = userDoc.getString("gender");
                                    if (gender == null) gender = "—";
                                    participantList.add(new ParticipantItem(uid, name, gender, role, joinedAt));

                                    pending[0]--;
                                    if (pending[0] == 0) {
                                        participantList.sort((a, b) -> Long.compare(a.joinedAt, b.joinedAt));
                                        progressParticipants.setVisibility(View.GONE);
                                        rvParticipants.setVisibility(View.VISIBLE);
                                        participantAdapter.notifyDataSetChanged();
                                    }
                                })
                                .addOnFailureListener(e -> {
                                    participantList.add(new ParticipantItem(uid, name, "—", role, joinedAt));

                                    pending[0]--;
                                    if (pending[0] == 0) {
                                        participantList.sort((a, b) -> Long.compare(a.joinedAt, b.joinedAt));
                                        progressParticipants.setVisibility(View.GONE);
                                        rvParticipants.setVisibility(View.VISIBLE);
                                        participantAdapter.notifyDataSetChanged();
                                    }
                                });
                    }
                })
                .addOnFailureListener(e -> {
                    progressParticipants.setVisibility(View.GONE);
                    tvNoParticipants.setVisibility(View.VISIBLE);
                    Toast.makeText(this, "Failed to load participants: " + e.getMessage(),
                            Toast.LENGTH_SHORT).show();
                });
    }

    private void updateHostButton() {
        switch (event.getStatus().toLowerCase()) {
            case "upcoming":
                btnJoin.setText("Mark as Ongoing");
                break;
            case "ongoing":
                btnJoin.setText("Mark as Finished");
                break;
            case "finished":
                btnJoin.setText("Delete Event");
                break;
        }

        btnJoin.setOnClickListener(v -> {
            switch (event.getStatus().toLowerCase()) {
                case "upcoming":
                    if (isEventTimeReached()) {
                        updateStatus("ongoing");
                    } else {
                        Toast.makeText(this,
                                "Event time has not been reached yet",
                                Toast.LENGTH_SHORT).show();
                    }
                    break;
                case "ongoing":
                    updateStatus("finished");
                    break;
                case "finished":
                    deleteEvent();
                    break;
            }
        });
    }

    private boolean isEventTimeReached() {
        try {
            String dateTimeStr = event.getDate() + " " + event.getTime();
            SimpleDateFormat sdf = new SimpleDateFormat(
                    "EEEE, dd MMM yyyy hh:mm a", Locale.getDefault());
            Date eventDateTime = sdf.parse(dateTimeStr);
            return eventDateTime != null &&
                    System.currentTimeMillis() >= eventDateTime.getTime();
        } catch (Exception e) {
            return false;
        }
    }

    private void updateStatus(String newStatus) {
        btnJoin.setEnabled(false);
        progressBar.setVisibility(View.VISIBLE);

        db.collection("volunteerEvents")
                .document(event.getEventId())
                .update("status", newStatus)
                .addOnSuccessListener(unused -> {
                    progressBar.setVisibility(View.GONE);
                    btnJoin.setEnabled(true);
                    event.setStatus(newStatus);
                    tvStatus.setText(newStatus.toUpperCase());
                    updateHostButton();
                    Toast.makeText(this,
                            "Status updated to " + newStatus,
                            Toast.LENGTH_SHORT).show();
                    tvStatus.setText(newStatus);
                })
                .addOnFailureListener(e -> {
                    progressBar.setVisibility(View.GONE);
                    btnJoin.setEnabled(true);
                    Toast.makeText(this,
                            "Failed to update status: " + e.getMessage(),
                            Toast.LENGTH_SHORT).show();
                });
    }

    private void deleteEvent() {
        btnJoin.setEnabled(false);
        progressBar.setVisibility(View.VISIBLE);

        DocumentReference eventRef = db.collection("volunteerEvents")
                .document(event.getEventId());

        eventRef.collection("participants")
                .get()
                .addOnSuccessListener(snapshot -> {
                    com.google.firebase.firestore.WriteBatch batch = db.batch();
                    for (com.google.firebase.firestore.DocumentSnapshot doc
                            : snapshot.getDocuments()) {
                        batch.delete(doc.getReference());
                    }
                    batch.commit()
                            .addOnSuccessListener(unused -> {
                                eventRef.delete()
                                        .addOnSuccessListener(unused2 -> {
                                            progressBar.setVisibility(View.GONE);
                                            Toast.makeText(this,
                                                    "Event deleted.",
                                                    Toast.LENGTH_SHORT).show();
                                            finish();
                                        })
                                        .addOnFailureListener(e -> {
                                            progressBar.setVisibility(View.GONE);
                                            btnJoin.setEnabled(true);
                                            Toast.makeText(this,
                                                    "Failed to delete event: " + e.getMessage(),
                                                    Toast.LENGTH_SHORT).show();
                                        });
                            })
                            .addOnFailureListener(e -> {
                                progressBar.setVisibility(View.GONE);
                                btnJoin.setEnabled(true);
                                Toast.makeText(this,
                                        "Failed to delete participants: " + e.getMessage(),
                                        Toast.LENGTH_SHORT).show();
                            });
                })
                .addOnFailureListener(e -> {
                    progressBar.setVisibility(View.GONE);
                    btnJoin.setEnabled(true);
                    Toast.makeText(this,
                            "Failed to fetch participants: " + e.getMessage(),
                            Toast.LENGTH_SHORT).show();
                });
    }


    private void checkIfJoined() {
        progressBar.setVisibility(View.VISIBLE);
        btnJoin.setEnabled(false);

        db.collection("volunteerEvents")
                .document(event.getEventId())
                .collection("participants")
                .document(currentUid)
                .get()
                .addOnSuccessListener(doc -> {
                    progressBar.setVisibility(View.GONE);
                    btnJoin.setEnabled(true);

                    if (doc.exists()) {
                        if ("cancelled".equals(event.getStatus())) {
                            btnJoin.setText("Event Cancelled");
                            btnJoin.setEnabled(false);
                            btnJoin.setAlpha(0.5f);
                            layoutChatButtons.setVisibility(View.GONE);
                            return;
                        }
                        isAlreadyJoined = true;
                        btnJoin.setText("Leave Event");
                        btnJoin.setEnabled(true);
                        btnJoin.setAlpha(1f);
                        layoutChatButtons.setVisibility(View.VISIBLE);
                        setMessageHostListener();
                    }else if (event.getVolunteersJoined() >= event.getVolunteersRequired()) {
                        btnJoin.setText("Event Full");
                        btnJoin.setEnabled(false);
                        btnJoin.setAlpha(0.5f);
                        layoutChatButtons.setVisibility(View.GONE);
                        return;
                    }
                    else {
                        if ("finished".equals(event.getStatus()) || "cancelled".equals(event.getStatus())) {
                            btnJoin.setText("finished".equals(event.getStatus()) ? "Event Ended" : "Event Cancelled");
                            btnJoin.setEnabled(false);
                            btnJoin.setAlpha(0.5f);
                            layoutChatButtons.setVisibility(View.GONE);
                            return;
                        }
                        isAlreadyJoined = false;
                        btnJoin.setText("Join");
                        btnJoin.setEnabled(true);
                        btnJoin.setAlpha(1f);
                        layoutChatButtons.setVisibility(View.GONE);
                    }

                    btnJoin.setOnClickListener(v -> {
                        if (isAlreadyJoined) leaveEvent();
                        else joinEvent();
                    });
                })
                .addOnFailureListener(e -> {
                    progressBar.setVisibility(View.GONE);
                    btnJoin.setEnabled(true);
                    Toast.makeText(this,
                            "Failed to check join status.",
                            Toast.LENGTH_SHORT).show();
                });
    }

    private void setMessageHostListener() {
        btnMessageHost.setOnClickListener(v -> {
            Intent intent = new Intent(this, ChatActivity.class);
            intent.putExtra("chatType", "direct");
            intent.putExtra("chatId",   event.getEventId() + "_dm_" + currentUid);
            intent.putExtra("chatName", event.getHostName());
            android.util.Log.d("INBOX", "DM chatId being used: " + event.getEventId() + "_dm_" + currentUid);
            startActivity(intent);
        });
    }

    private void showCancelDialog() {
        View view = getLayoutInflater().inflate(R.layout.dialog_cancel_gathering, null);

        BottomSheetDialog sheet = new BottomSheetDialog(this, R.style.CancelGatheringSheetTheme);
        sheet.setContentView(view);

        if (sheet.getWindow() != null) {
            sheet.getWindow().setBackgroundDrawable(
                    new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
        }

        RadioGroup rgReasons = view.findViewById(R.id.rgReasons);
        Button btnGoBack     = view.findViewById(R.id.btnDialogGoBack);
        AppCompatButton btnConfirm    = view.findViewById(R.id.btnDialogConfirm);

        btnGoBack.setOnClickListener(v -> sheet.dismiss());
        btnConfirm.setOnClickListener(v -> {
            int selectedId = rgReasons.getCheckedRadioButtonId();
            if (selectedId == -1) {
                Toast.makeText(this, "Please select a reason", Toast.LENGTH_SHORT).show();
                return;
            }
            RadioButton selected = view.findViewById(selectedId);
            sheet.dismiss();
            cancelEvent(selected.getText().toString());
        });

        sheet.show();
    }

    private void cancelEvent(String reason) {
        btnCancelEvent.setEnabled(false);
        btnJoin.setEnabled(false);
        progressBar.setVisibility(View.VISIBLE);

        Map<String, Object> updates = new HashMap<>();
        updates.put("status", "cancelled");
        updates.put("cancellationReason", reason);
        updates.put("cancelledAt", System.currentTimeMillis());

        db.collection("volunteerEvents")
                .document(event.getEventId())
                .update(updates)
                .addOnSuccessListener(unused -> {
                    progressBar.setVisibility(View.GONE);
                    event.setStatus("cancelled");
                    tvStatus.setText("CANCELLED");
                    tvStatus.setTextColor(getColor(android.R.color.holo_red_light));
                    btnJoin.setText("Event Cancelled");
                    btnJoin.setEnabled(false);
                    btnJoin.setAlpha(0.5f);
                    btnCancelEvent.setVisibility(View.GONE);
                    layoutChatButtons.setVisibility(View.GONE);
                    Toast.makeText(this, "Event cancelled: " + reason, Toast.LENGTH_LONG).show();
                })
                .addOnFailureListener(e -> {
                    progressBar.setVisibility(View.GONE);
                    btnCancelEvent.setEnabled(true);
                    btnJoin.setEnabled(true);
                    Toast.makeText(this, "Failed to cancel: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                });
    }

    private void joinEvent() {
        if (event.getVolunteersJoined() >= event.getVolunteersRequired()) {
            Toast.makeText(this, "Sorry, this event is full.", Toast.LENGTH_SHORT).show();
            return;
        }
        btnJoin.setEnabled(false);
        progressBar.setVisibility(View.VISIBLE);

        db.collection("users")
                .document(currentUid)
                .get()
                .addOnSuccessListener(userDoc -> {
                    String userName = userDoc.getString("name");

                    DocumentReference eventRef = db.collection("volunteerEvents")
                            .document(event.getEventId());

                    Map<String, Object> entry = new HashMap<>();
                    entry.put("uid",      currentUid);
                    entry.put("name",     userName);
                    entry.put("role",     "participant");
                    entry.put("joinedAt", System.currentTimeMillis());

                    eventRef.collection("participants")
                            .document(currentUid)
                            .set(entry)
                            .addOnSuccessListener(unused -> {
                                eventRef.update("volunteersJoined",
                                                FieldValue.increment(1))
                                        .addOnSuccessListener(unused2 -> {
                                            progressBar.setVisibility(View.GONE);
                                            btnJoin.setEnabled(true);
                                            isAlreadyJoined = true;
                                            btnJoin.setText("Leave Event");
                                            layoutChatButtons.setVisibility(View.VISIBLE);
                                            setMessageHostListener();

                                            int newCount = event.getVolunteersJoined() + 1;
                                            event.setVolunteersJoined(newCount);
                                            tvSlots.setText(newCount + "/" + event.getVolunteersRequired());
                                            tvParticipantCount.setText(newCount + " Attending");

                                            Toast.makeText(this,
                                                    "You have joined the event!",
                                                    Toast.LENGTH_SHORT).show();
                                        });
                            })
                            .addOnFailureListener(e -> {
                                progressBar.setVisibility(View.GONE);
                                btnJoin.setEnabled(true);
                                Toast.makeText(this,
                                        "Failed to join: " + e.getMessage(),
                                        Toast.LENGTH_SHORT).show();
                            });
                })
                .addOnFailureListener(e -> {
                    progressBar.setVisibility(View.GONE);
                    btnJoin.setEnabled(true);
                    Toast.makeText(this,
                            "Failed to fetch user info.",
                            Toast.LENGTH_SHORT).show();
                });
    }

    private void leaveEvent() {
        btnJoin.setEnabled(false);
        progressBar.setVisibility(View.VISIBLE);

        DocumentReference eventRef = db.collection("volunteerEvents")
                .document(event.getEventId());

        eventRef.collection("participants")
                .document(currentUid)
                .delete()
                .addOnSuccessListener(unused -> {
                    eventRef.update("volunteersJoined",
                                    FieldValue.increment(-1))
                            .addOnSuccessListener(unused2 -> {
                                progressBar.setVisibility(View.GONE);
                                btnJoin.setEnabled(true);
                                isAlreadyJoined = false;
                                btnJoin.setText("Join");
                                layoutChatButtons.setVisibility(View.GONE);

                                int newCount = Math.max(0, event.getVolunteersJoined() - 1);
                                event.setVolunteersJoined(newCount);
                                tvSlots.setText(newCount + "/" + event.getVolunteersRequired());
                                tvParticipantCount.setText(newCount + " Attending");

                                Toast.makeText(this,
                                        "You have left the event.",
                                        Toast.LENGTH_SHORT).show();
                            });
                })
                .addOnFailureListener(e -> {
                    progressBar.setVisibility(View.GONE);
                    btnJoin.setEnabled(true);
                    Toast.makeText(this,
                            "Failed to leave: " + e.getMessage(),
                            Toast.LENGTH_SHORT).show();
                });
    }

    private void openGoogleMaps() {
        String uri = "geo:" + event.getLat() + "," + event.getLng() +
                "?q=" + event.getLat() + "," + event.getLng() +
                "(" + Uri.encode(event.getLocation()) + ")";

        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(uri));
        intent.setPackage("com.google.android.apps.maps");

        if (intent.resolveActivity(getPackageManager()) != null) {
            startActivity(intent);
        } else {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(uri)));
        }
    }
}