package com.example.gatherforgood;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class SplashScreen extends AppCompatActivity {

    Animation blink;
    View statusDot;
    SharedPreferences sPref;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_splash_screen);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        init();
        ApplyAnimation();

        Intent intent;
        if (checkAlreadyLoggedIn()) {
            intent = new Intent(SplashScreen.this, HomeScreen.class);
        } else if (!hasSeenOnboarding()) {
            intent = new Intent(SplashScreen.this, OnboardingScreen.class);
        } else {
            intent = new Intent(SplashScreen.this, LoginScreen.class);
        }

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                startActivity(intent);
                finish();
            }
        },3000);
    }

    public void init(){
        statusDot = findViewById(R.id.statusDot);
        sPref = getSharedPreferences("user", MODE_PRIVATE);
    }

    public boolean hasSeenOnboarding() {
        return sPref.getBoolean("hasSeenOnboarding", false);
    }
    
    public boolean checkAlreadyLoggedIn(){

        if(!sPref.getBoolean("isLoggedIn",false)){
            return false;
        }
        return true;
    }

    public void ApplyAnimation(){
        blink = AnimationUtils.loadAnimation(this,R.anim.anim_blink);
        statusDot.setAnimation(blink);
    }

}